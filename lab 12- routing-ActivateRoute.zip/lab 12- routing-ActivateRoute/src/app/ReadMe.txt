What is child routing 
Where it is needed
-- it is needed when under one parent menu there are numbers of menu .

How to set  child routing :using children

{ path: 'users', component:UsersComponent , 
    children:[{ path: ':id/:name', component:UserComponent }]
},

--- <router-outlet></router-outlet> in same parent components

 ngOnInit() {
    this.server = this.serversService.getServer(this.route.snapshot.params['id']);
    this.route.params
      .subscribe(
        (params: Params) => {
          //alert(params['id']);
          this.server = this.serversService.getServer(+params['id']);
          
        }
      );

  }

import { Component, OnInit, OnDestroy } from '@angular/core';

--fetch value from ruting 
import { ActivatedRoute, Params } from '@angular/router';

import { Subscription } from 'rxjs/Subscription';

this.paramsSubscription = this.route.params
      .subscribe(
        (params: Params) => {
          this.user.id = params['id'];
          this.user.name = params['name'];
        }
      );
      
 ngOnDestroy() {
    this.paramsSubscription.unsubscribe();
  }