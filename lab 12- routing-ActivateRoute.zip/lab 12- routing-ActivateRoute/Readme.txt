Two way to read parameter 

One when componnets is loaded

2nd when component loaded and any link on this components is clicked, at that time you have to use Subscription